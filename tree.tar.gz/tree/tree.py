
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.cross_validation import train_test_split
from sklearn.metrics import classification_report


# In[2]:

data = pd.read_csv('data_deleted.csv')
train, test = train_test_split(data)
clf = DecisionTreeClassifier()
clf.fit(train.iloc[:, :-1], train.iloc[:, -1])
clf.score(test.iloc[:, :-1], test.iloc[:, -1])
print(test.iloc[1:10, -1])
clf.predict(test.iloc[1:10, :-1])


# In[3]:

# test.iloc[:, -1]


# In[4]:

print(classification_report(test.iloc[:, -1], clf.predict(test.iloc[:, :-1])))


# In[5]:

print(test.iloc[1, :]),  clf.predict(test.iloc[1, :-1].reshape(1, -1))


# In[121]:

df = pd.read_csv('CAP-DNPS-012-03.csv',header=None)
print(clf.predict(df.iloc[0, :-1].reshape(1, -1)))

